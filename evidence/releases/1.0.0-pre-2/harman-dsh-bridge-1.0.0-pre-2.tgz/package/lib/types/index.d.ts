import type { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { JsonValue } from './types.js';
export declare class HarmanGateway extends TypertRemoteService {
    constructor(ctx: Context);
    snapshot(): Promise<JsonValue>;
    query(subject: string, input: JsonValue): Promise<JsonValue>;
    preview(action: string, input: JsonValue): Promise<JsonValue>;
    execute(action: string, input: JsonValue, expectedRevision: number, confirmed: boolean): Promise<JsonValue>;
}
export default HarmanGateway;

import type { Context } from '@deepseek-ai/cordis';
import type { JsonValue } from '@deepseek-ai/dsh-session/types';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
export declare class HarmanGateway extends TypertRemoteService {
    constructor(ctx: Context);
    snapshot(): Promise<JsonValue>;
    query(subject: string, input: JsonValue): Promise<JsonValue>;
    preview(action: string, input: JsonValue): Promise<JsonValue>;
    execute(action: string, input: JsonValue, expectedRevision: number, confirmed: boolean): Promise<JsonValue>;
}
export default HarmanGateway;
//# sourceMappingURL=index.d.ts.map